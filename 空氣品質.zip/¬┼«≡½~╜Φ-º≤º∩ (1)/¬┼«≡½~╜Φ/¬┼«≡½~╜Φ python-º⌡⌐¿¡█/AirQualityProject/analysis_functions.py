import pandas as pd
import matplotlib.pyplot as plt
import os

# 設定字體以支援中文
plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei'] 
plt.rcParams['axes.unicode_minus'] = False

def load_data():
    if os.path.exists('air_data.csv'):
        try:
            df = pd.read_csv('air_data.csv', encoding='utf-8-sig')
        except:
            df = pd.read_csv('air_data.csv', encoding='big5')
        
        # 【預防機制】統一欄位名稱，避免 KeyError
        cols = {c.lower(): c for c in df.columns}
        if 'city' in cols: df['City'] = df[cols['city']]
        if 'district' in cols: df['District'] = df[cols['district']]
        
        # 統一將「台」轉為「臺」
        if 'City' in df.columns:
            df['City'] = df['City'].astype(str).str.replace('台', '臺')
        if 'District' in df.columns:
            df['District'] = df['District'].astype(str).str.replace('台', '臺')
        
        # 確保 PM2.5 是數字
        if 'PM2.5' in df.columns:
            df['PM2.5'] = pd.to_numeric(df['PM2.5'], errors='coerce')
            
        return df
    return None

def process_and_analyze_data(df, city, district, year):
    # 參數標準化
    city = city.replace('台', '臺')
    district = district.replace('台', '臺')
    
    mask = (df['City'] == city) & (df['District'] == district) & (df['Year'] == year)
    filtered_df = df[mask].copy()
    
    if filtered_df.empty:
        return None, 0
    
    monthly_avg = filtered_df.groupby('Month')['PM2.5'].mean().reset_index().sort_values('Month')
    yearly_avg = filtered_df['PM2.5'].mean()
    
    return monthly_avg, yearly_avg

def generate_visualizations(monthly_df, city, district, year):
    # 使用英文檔名預防路徑編碼報錯
    bar_filename = f"bar_temp.png"
    line_filename = f"line_temp.png"
    
    # 長條圖
    plt.figure(figsize=(8, 4))
    plt.bar(monthly_df['Month'], monthly_df['PM2.5'], color='coral')
    plt.title(f"{year} {city}{district} PM2.5 月平均")
    plt.xticks(range(1, 13))
    plt.tight_layout()
    plt.savefig(bar_filename)
    plt.close()
    
    # 折線圖
    plt.figure(figsize=(8, 4))
    plt.plot(monthly_df['Month'], monthly_df['PM2.5'], marker='o', color='orange')
    plt.title(f"{year} {city}{district} 趨勢圖")
    plt.xticks(range(1, 13))
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(line_filename)
    plt.close()
    
    return bar_filename, line_filename
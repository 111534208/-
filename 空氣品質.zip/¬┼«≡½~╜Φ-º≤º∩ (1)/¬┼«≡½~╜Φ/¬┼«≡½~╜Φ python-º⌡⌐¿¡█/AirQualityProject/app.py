import os
import uuid
import pandas as pd
import matplotlib
# --- 核心修正：必須在 import plt 之前設定後端，防止網頁環境崩潰 ---
matplotlib.use('Agg') 
import matplotlib.pyplot as plt

from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS
from analysis_functions import load_data, process_and_analyze_data
from generate_data import generate_csv

app = Flask(__name__)
CORS(app)  # 允許跨網域存取

# 設定圖片儲存目錄
IMAGE_DIR = "static_charts"
if not os.path.exists(IMAGE_DIR):
    os.makedirs(IMAGE_DIR)

# 啟動時先載入資料
GLOBAL_DF = load_data()

def clear_old_images():
    """啟動時清空舊圖，避免佔用空間"""
    if os.path.exists(IMAGE_DIR):
        for f in os.listdir(IMAGE_DIR):
            if f.endswith(".png"):
                try:
                    os.remove(os.path.join(IMAGE_DIR, f))
                except:
                    pass

# --- [路由] 首頁：直接提供 index.html ---
@app.route('/')
def index():
    return send_file('index.html')

# --- [路由] 管理員登入 ---
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if username == "admin" and password == "1234":
        return jsonify({"success": True, "message": "歡迎回來，管理員！"})
    else:
        return jsonify({"success": False, "message": "帳號或密碼錯誤"}), 401

# --- [路由] 管理員刷新資料庫 ---
@app.route('/admin/refresh_data', methods=['POST'])
def refresh_data():
    global GLOBAL_DF
    try:
        generate_csv()
        GLOBAL_DF = load_data()
        return jsonify({"success": True, "message": "資料庫已成功更新並重載！"})
    except Exception as e:
        return jsonify({"success": False, "message": f"刷新失敗: {str(e)}"}), 500

# --- [全台縣市概況 API] ---
@app.route('/api/city_summary', methods=['GET'])
def get_city_summary():
    global GLOBAL_DF
    try:
        if GLOBAL_DF is None:
            GLOBAL_DF = load_data()
            if GLOBAL_DF is None:
                return jsonify({"error": "找不到資料庫檔案，請聯絡管理員"}), 500
        
        summary = GLOBAL_DF.groupby('City')['PM2.5'].mean().reset_index()
        result = []
        for _, row in summary.iterrows():
            val = round(row['PM2.5'], 1)
            if val <= 15:
                status, color = "良好", "#2ecc71"
            elif val <= 35:
                status, color = "普通", "#f1c40f"
            else:
                status, color = "不佳", "#e67e22"
            
            result.append({
                "city": row['City'],
                "avg": val,
                "status": status,
                "color": color
            })
        
        result = sorted(result, key=lambda x: x['avg'])
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": f"獲取概況失敗: {str(e)}"}), 500

# --- [路由] 空氣品質分析 (已加入防呆修正) ---
@app.route('/analyze', methods=['GET'])
def analyze():
    global GLOBAL_DF
    try:
        # 【防呆 1】確保資料庫不是空的，否則 .copy() 會報錯
        if GLOBAL_DF is None:
            GLOBAL_DF = load_data()
            if GLOBAL_DF is None:
                return jsonify({"error": "系統內無資料，請先執行 generate_data.py"}), 500
        
        city = request.args.get('city', '')
        district = request.args.get('district', '')
        year_str = request.args.get('year', '2025')
        
        try:
            year = int(year_str)
        except:
            year = 2025

        if not city or not district:
            return jsonify({"error": "請完整選擇縣市與行政區"}), 400

        # 【防呆 2】處理分析函數回傳 None 的情況
        result = process_and_analyze_data(GLOBAL_DF.copy(), city, district, year)
        
        if result is None or result[0] is None:
            return jsonify({"error": f"找不到 {city}{district} 在 {year} 年的數據"}), 404
        
        monthly_df, yearly_avg = result

        if monthly_df.empty:
            return jsonify({"error": f"{city}{district} 數據內容為空"}), 404

        # 2. 狀態判斷與建議
        if yearly_avg <= 15:
            status, color, suggest = "良好", "#2ecc71", "✨ 空氣清新，適合戶外運動。"
        elif yearly_avg <= 35:
            status, color, suggest = "普通", "#f1c40f", "🌤️ 品質普通，敏感族群請留意。"
        else:
            status, color, suggest = "不健康", "#e67e22", "😷 濃度偏高，建議配戴口罩。"

        # 3. 縣市內排名計算
        try:
            search_city = city.replace('台', '臺')
            search_dist = district.replace('台', '臺')
            city_data = GLOBAL_DF[GLOBAL_DF['City'] == search_city]
            city_avg = city_data.groupby('District')['PM2.5'].mean().sort_values()
            rank = list(city_avg.index).index(search_dist) + 1
        except:
            rank = "--"

        # 4. 產生圖表
        uid = str(uuid.uuid4())[:8]
        bar_name = f"bar_{uid}.png"
        line_name = f"line_{uid}.png"
        
        plt.figure(figsize=(8, 4))
        plt.bar(monthly_df['Month'], monthly_df['PM2.5'], color='coral')
        plt.title(f"{year} {city}{district} PM2.5 Monthly")
        plt.savefig(os.path.join(IMAGE_DIR, bar_name))
        plt.close()

        plt.figure(figsize=(8, 4))
        plt.plot(monthly_df['Month'], monthly_df['PM2.5'], marker='o', color='orange')
        plt.title(f"{year} {city}{district} Trend")
        plt.savefig(os.path.join(IMAGE_DIR, line_name))
        plt.close()

        # 5. 回傳結果
        return jsonify({
            "city": city,
            "district": district,
            "yearly_average_pm25": round(yearly_avg, 2),
            "air_status": status,
            "status_color": color,
            "air_suggestion": suggest,
            "rank": rank,
            "attainment_rate": round((monthly_df['PM2.5'] <= 15).sum() / len(monthly_df) * 100, 1),
            "bar_chart_filename": bar_name,
            "line_chart_filename": line_name
        })
    except Exception as e:
        # 最外層的防線：捕捉所有未預期的錯誤
        return jsonify({"error": f"系統運算錯誤: {str(e)}"}), 500

# --- [路由] 讀取圖表檔案 ---
@app.route('/image/<filename>')
def get_image(filename):
    return send_from_directory(IMAGE_DIR, filename)

if __name__ == '__main__':
    clear_old_images()  # 啟動前清空舊圖
    print("Server is starting at http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
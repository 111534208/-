import os
import uuid
import json
import pandas as pd
import matplotlib
import io  # --- 新增：處理 Excel 輸出 ---
# --- 核心修正：必須在 import plt 之前設定後端，防止網頁環境崩潰 ---
matplotlib.use('Agg') 
import matplotlib.pyplot as plt

from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS
from analysis_functions import load_data, process_and_analyze_data
from generate_data import generate_csv

app = Flask(__name__)
CORS(app)

# 設定目錄
IMAGE_DIR = "static_charts"
ANN_FILE = "announcement.json"  # 公告存檔路徑

if not os.path.exists(IMAGE_DIR):
    os.makedirs(IMAGE_DIR)

# --- [功能] 公告存取邏輯 ---
def load_announcement_from_file():
    """從檔案載入公告，若無檔案則給予預設值"""
    default_ann = {
        "content": "歡迎使用空氣品質分析系統！目前全台數據監測中。",
        "type": "info",
        "is_active": True
    }
    if os.path.exists(ANN_FILE):
        try:
            with open(ANN_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default_ann
    return default_ann

def save_announcement_to_file(ann_data):
    """將公告儲存至檔案"""
    with open(ANN_FILE, 'w', encoding='utf-8') as f:
        json.dump(ann_data, f, ensure_ascii=False, indent=4)

# 初始化公告變數
current_announcement = load_announcement_from_file()

# 啟動時載入大數據資料
GLOBAL_DF = load_data()

def clear_old_images():
    if os.path.exists(IMAGE_DIR):
        for f in os.listdir(IMAGE_DIR):
            if f.endswith(".png"):
                try:
                    os.remove(os.path.join(IMAGE_DIR, f))
                except:
                    pass

# --- [路由] 首頁 ---
@app.route('/')
def index():
    return send_file('index.html')

# --- [新增路由] 下載數據 Excel ---
@app.route('/download_excel', methods=['GET'])
def download_excel():
    global GLOBAL_DF
    try:
        city = request.args.get('city', '')
        district = request.args.get('district', '')
        year = int(request.args.get('year', 2025))
        
        # 使用你現有的數據分析函數取得資料
        monthly_df, _ = process_and_analyze_data(GLOBAL_DF.copy(), city, district, year)
        
        if monthly_df is None or monthly_df.empty:
            return "查無數據可供下載", 404

        # 將 DataFrame 轉為 Excel 二進位流（不產生實體檔案，直接回傳給瀏覽器）
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            monthly_df.to_excel(writer, index=False, sheet_name='空氣品質數據')
        output.seek(0)

        file_name = f"{year}_{city}{district}_PM25.xlsx"
        return send_file(
            output, 
            as_attachment=True, 
            download_name=file_name, 
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
    except Exception as e:
        return f"下載失敗: {str(e)}", 500

# --- [路由] 獲取目前公告 ---
@app.route('/api/announcement', methods=['GET'])
def get_announcement():
    global current_announcement
    return jsonify(current_announcement)

# --- [路由] 管理員登入 ---
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    if username == "admin" and password == "1234":
        return jsonify({"success": True, "message": "歡迎回來！"})
    return jsonify({"success": False, "message": "帳號或密碼錯誤"}), 401

# --- [路由] 管理員發布/修改公告 ---
@app.route('/admin/update_announcement', methods=['POST'])
def update_announcement():
    global current_announcement
    try:
        data = request.json
        content = data.get("content", "").strip()
        if not content:
            return jsonify({"success": False, "message": "內容不能為空"}), 400
            
        current_announcement = {
            "content": content,
            "type": data.get("type", "info"),
            "is_active": True
        }
        save_announcement_to_file(current_announcement) # 存檔
        return jsonify({"success": True, "message": "公告已發布並存檔！"})
    except Exception as e:
        return jsonify({"success": False, "message": f"發布失敗: {str(e)}"}), 500

# --- [路由] 管理員刪除/撤下公告 ---
@app.route('/admin/delete_announcement', methods=['DELETE'])
def delete_announcement():
    global current_announcement
    try:
        current_announcement = {
            "content": "",
            "type": "info",
            "is_active": False
        }
        save_announcement_to_file(current_announcement) # 存檔
        return jsonify({"success": True, "message": "公告已成功撤除！"})
    except Exception as e:
        return jsonify({"success": False, "message": f"刪除失敗: {str(e)}"}), 500

# --- [路由] 管理員刷新資料庫 ---
@app.route('/admin/refresh_data', methods=['POST'])
def refresh_data():
    global GLOBAL_DF
    try:
        generate_csv()
        GLOBAL_DF = load_data()
        return jsonify({"success": True, "message": "資料庫已重載！"})
    except Exception as e:
        return jsonify({"success": False, "message": f"失敗: {str(e)}"}), 500

# --- [路由] 全台縣市概況 ---
@app.route('/api/city_summary', methods=['GET'])
def get_city_summary():
    global GLOBAL_DF
    try:
        if GLOBAL_DF is None: GLOBAL_DF = load_data()
        summary = GLOBAL_DF.groupby('City')['PM2.5'].mean().reset_index()
        result = []
        for _, row in summary.iterrows():
            val = round(row['PM2.5'], 1)
            if val <= 15: status, color = "良好", "#2ecc71"
            elif val <= 35: status, color = "普通", "#f1c40f"
            else: status, color = "不佳", "#e67e22"
            result.append({"city": row['City'], "avg": val, "status": status, "color": color})
        return jsonify(sorted(result, key=lambda x: x['avg']))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- [路由] 空氣品質分析 ---
@app.route('/analyze', methods=['GET'])
def analyze():
    global GLOBAL_DF
    try:
        if GLOBAL_DF is None: GLOBAL_DF = load_data()
        city = request.args.get('city', '')
        district = request.args.get('district', '')
        year = int(request.args.get('year', 2025))

        monthly_df, yearly_avg = process_and_analyze_data(GLOBAL_DF.copy(), city, district, year)
        
        if monthly_df is None or monthly_df.empty:
            return jsonify({"error": "找不到數據"}), 404

        # 狀態判斷
        if yearly_avg <= 15: status, color, suggest = "良好", "#2ecc71", "✨ 空氣清新，適合戶外運動。"
        elif yearly_avg <= 35: status, color, suggest = "普通", "#f1c40f", "🌤️ 品質普通，敏感族群請留意。"
        else: status, color, suggest = "不健康", "#e67e22", "😷 濃度偏高，建議配戴口罩。"

        # 排名計算
        try:
            search_city = city.replace('台', '臺')
            search_dist = district.replace('台', '臺')
            city_data = GLOBAL_DF[GLOBAL_DF['City'] == search_city]
            city_avg = city_data.groupby('District')['PM2.5'].mean().sort_values()
            rank = list(city_avg.index).index(search_dist) + 1
        except:
            rank = "--"

        uid = str(uuid.uuid4())[:8]
        bar_name, line_name = f"bar_{uid}.png", f"line_{uid}.png"
        
        plt.figure(figsize=(8, 4))
        plt.bar(monthly_df['Month'], monthly_df['PM2.5'], color='coral')
        plt.title(f"{year} {city}{district} PM2.5 Monthly")
        plt.savefig(os.path.join(IMAGE_DIR, bar_name)); plt.close()

        plt.figure(figsize=(8, 4))
        plt.plot(monthly_df['Month'], monthly_df['PM2.5'], marker='o', color='orange')
        plt.title(f"{year} {city}{district} Trend")
        plt.savefig(os.path.join(IMAGE_DIR, line_name)); plt.close()

        return jsonify({
            "city": city, "district": district, "yearly_average_pm25": round(yearly_avg, 2),
            "air_status": status, "status_color": color, "air_suggestion": suggest,
            "rank": rank, "attainment_rate": round((monthly_df['PM2.5'] <= 15).sum() / len(monthly_df) * 100, 1),
            "bar_chart_filename": bar_name, "line_chart_filename": line_name
        })
    except Exception as e:
        return jsonify({"error": f"運算錯誤: {str(e)}"}), 500

@app.route('/image/<filename>')
def get_image(filename):
    return send_from_directory(IMAGE_DIR, filename)

if __name__ == '__main__':
    clear_old_images()
    print("Backend Running: http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
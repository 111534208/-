import threading
import requests
import time

# 這是你的後端網址 (確保 app.py 正在運行)
URL = "http://127.0.0.1:5000/analyze?city=台北市&district=中正區&year=2025"

def task(i):
    print(f"正在發送第 {i+1} 個請求...")
    try:
        start = time.time()
        # 向 Flask 伺服器請求數據，設定 5 秒超時
        r = requests.get(URL, timeout=5)
        print(f"請求 {i+1} 成功 - 狀態: {r.status_code}, 耗時: {time.time()-start:.2f}秒")
    except Exception as e:
        print(f"請求 {i+1} 失敗: {e}")

if __name__ == "__main__":
    print("--- 壓力測試準備開始 (模擬 10 人同時連線) ---")
    
    # 建立 10 個執行緒模擬同時存取 [原本為 50，現在改為 10 以降低伺服器負擔]
    threads = []
    for i in range(10):
        t = threading.Thread(target=task, args=(i,))
        threads.append(t)
    
    print("🚀 啟動所有執行緒...")
    for t in threads:
        t.start()

    # 等待所有線程跑完
    for t in threads:
        t.join()
    
    print("--- 測試結束 ---")
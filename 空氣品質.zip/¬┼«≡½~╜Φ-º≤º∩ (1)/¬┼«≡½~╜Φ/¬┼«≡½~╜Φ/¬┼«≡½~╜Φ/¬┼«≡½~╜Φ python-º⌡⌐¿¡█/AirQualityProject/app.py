import os
import uuid
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # 必備：確保在伺服器背景繪圖不會崩潰
import matplotlib.pyplot as plt
from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS
from datetime import datetime, timedelta

# --- 1. 基礎路徑與環境檢查 ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGE_DIR = os.path.join(BASE_DIR, "static_charts")
CSV_PATH = os.path.join(BASE_DIR, 'air_data.csv')

# 【防呆】啟動時自動檢查並建立圖片資料夾，避免檔案寫入失敗
if not os.path.exists(IMAGE_DIR): 
    os.makedirs(IMAGE_DIR)

app = Flask(__name__)
CORS(app)

# Matplotlib 中文顯示設定
plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei'] 
plt.rcParams['axes.unicode_minus'] = False

admin_logs = []

# --- 2. 核心防呆工具 ---

def normalize_name(name):
    """ 【防呆】自動處理『台/臺』爭議與空格，確保資料對比永遠成功 """
    if not name or not isinstance(name, str):
        return ""
    return name.replace('台', '臺').strip()

def cleanup_old_images():
    """ 【防呆】資源回收機制：自動刪除 10 分鐘前的圖檔，防止硬碟爆滿 """
    now = datetime.now()
    try:
        if os.path.exists(IMAGE_DIR):
            for f in os.listdir(IMAGE_DIR):
                f_path = os.path.join(IMAGE_DIR, f)
                # 檢查檔案建立時間，超過 10 分鐘就刪除
                if os.path.getmtime(f_path) < (now - timedelta(minutes=10)).timestamp():
                    os.remove(f_path)
    except Exception as e:
        print(f"清理舊圖失敗: {e}")

def load_data():
    """ 【防呆】超強讀取：自動過濾壞數據、修正亂碼、檢查欄位 """
    if not os.path.exists(CSV_PATH):
        return None
    try:
        # 嘗試多種編碼（解決 Excel 存檔造成的亂碼問題）
        try:
            df = pd.read_csv(CSV_PATH, encoding='utf-8-sig')
        except:
            df = pd.read_csv(CSV_PATH, encoding='big5')
        
        # 欄位完整性檢查
        required = ['City', 'District', 'Month', 'PM2.5']
        if not all(col in df.columns for col in required):
            print("警告：CSV 欄位名稱不符！")
            return None
            
        # 數據清洗：強制轉換 PM2.5 為數字，壞掉的內容變空值再刪除
        df['PM2.5'] = pd.to_numeric(df['PM2.5'], errors='coerce')
        df = df.dropna(subset=['PM2.5'])
        
        # 統一處理資料庫內的名稱
        df['City'] = df['City'].apply(normalize_name)
        df['District'] = df['District'].apply(normalize_name)
        
        return df
    except Exception as e:
        print(f"數據加載失敗: {e}")
        return None

# --- 3. 核心路由實作 ---

@app.route('/analyze', methods=['GET'])
def analyze():
    cleanup_old_images() # 每次查詢時順便清掃垃圾圖檔
    
    # 參數獲取與預處理
    city = normalize_name(request.args.get('city', ''))
    district = normalize_name(request.args.get('district', ''))
    
    if not city or not district:
        return jsonify({"error": "請選擇縣市與行政區"}), 400

    df = load_data()
    if df is None: 
        return jsonify({"error": "找不到資料庫檔案，請管理員點擊『重新生成數據』"}), 500

    # 數據過濾
    mask = (df['City'] == city) & (df['District'] == district)
    monthly_df = df[mask].sort_values('Month')

    if monthly_df.empty:
        return jsonify({"error": f"找不到 {city}{district} 的數據"}), 404
    
    # 指標計算
    yearly_avg = round(monthly_df['PM2.5'].mean(), 2)
    city_group = df[df['City'] == city].groupby('District')['PM2.5'].mean().sort_values()
    rank = list(city_group.index).index(district) + 1 if district in city_group.index else 0
    attainment_rate = round(((monthly_df['PM2.5'] <= 15).sum() / 12) * 100, 1)

    # 狀態判斷
    if yearly_avg <= 15: status, color, suggest = "良好", "#2ecc71", "✨ 空氣清新，適合戶外運動！"
    elif yearly_avg <= 35: status, color, suggest = "普通", "#f1c40f", "🌤️ 品質普通，留意環境變化。"
    else: status, color, suggest = "不健康", "#e67e22", "😷 建議佩戴口罩。"

    # 圖表生成 (UUID 避免瀏覽器快取舊圖)
    uid = str(uuid.uuid4())[:8]
    bar_name = f"bar_{uid}.png"
    line_name = f"line_{uid}.png"

    try:
        # 柱狀圖
        plt.figure(figsize=(8, 4))
        plt.bar(monthly_df['Month'], monthly_df['PM2.5'], color='#ff8a65')
        plt.title(f"{city}{district} - PM2.5 月統計")
        plt.ylabel("µg/m³")
        plt.savefig(os.path.join(IMAGE_DIR, bar_name))
        plt.close() # 重要：繪圖完必關閉，避免內存溢出

        # 折線圖
        plt.figure(figsize=(8, 4))
        plt.plot(monthly_df['Month'], monthly_df['PM2.5'], marker='o', color='#3498db', linewidth=2)
        plt.title(f"{city}{district} - 年度趨勢")
        plt.grid(True, linestyle='--', alpha=0.5)
        plt.savefig(os.path.join(IMAGE_DIR, line_name))
        plt.close()
    except Exception as e:
        return jsonify({"error": f"圖片生成失敗: {str(e)}"}), 500

    return jsonify({
        "city": city, "district": district,
        "yearly_average_pm25": yearly_avg,
        "air_status": status, "status_color": color, 
        "air_suggestion": suggest,
        "ai_prediction": f"預測下季度 {city} 污染將{'穩定' if yearly_avg < 25 else '略微改善'}。",
        "rank": f"{rank} / {len(city_group)}", 
        "attainment_rate": attainment_rate,
        "bar_chart_filename": bar_name,
        "line_chart_filename": line_name
    })

# --- 4. 管理員與功能路由 ---

@app.route('/login', methods=['POST'])
def login():
    data = request.json or {}
    if data.get('username') == 'admin' and data.get('password') == '1234':
        admin_logs.append(f"管理員於 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 登入成功")
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "帳號或密碼錯誤"})

@app.route('/admin/logs', methods=['GET'])
def get_logs():
    return jsonify(admin_logs[-5:])

@app.route('/admin/refresh_data', methods=['POST'])
def refresh_database_api():
    try:
        from generate_data import generate_csv 
        generate_csv()
        # 更新後自動清空舊圖
        for f in os.listdir(IMAGE_DIR):
            os.remove(os.path.join(IMAGE_DIR, f))
        return jsonify({"message": "資料庫已重置，快取圖檔已清空！"})
    except Exception as e:
        return jsonify({"message": f"重置失敗: {str(e)}"}), 500

@app.route('/api/city_summary')
def city_summary():
    df = load_data()
    if df is None: return jsonify([])
    summary = df.groupby('City')['PM2.5'].mean().reset_index()
    results = []
    for _, row in summary.iterrows():
        avg = round(row['PM2.5'], 1)
        status, color = ("良好", "#2ecc71") if avg <= 15 else (("普通", "#f1c40f") if avg <= 35 else ("不健康", "#e67e22"))
        results.append({"city": row['City'], "avg": avg, "status": status, "color": color})
    return jsonify(results)

@app.route('/api/export')
def export_data():
    city = normalize_name(request.args.get('city'))
    dist = normalize_name(request.args.get('district'))
    df = load_data()
    if df is None: return "Database not found", 404
    
    target = df[(df['City'] == city) & (df['District'] == dist)]
    if target.empty: return "No data found", 404
    
    path = os.path.join(BASE_DIR, f"export_{city}_{dist}.csv")
    # 使用 utf-8-sig 確保 Excel 打開不亂碼
    target.to_csv(path, index=False, encoding='utf-8-sig')
    return send_file(path, as_attachment=True)

@app.route('/image/<filename>')
def get_image(filename):
    if not os.path.exists(os.path.join(IMAGE_DIR, filename)):
        return "Image Not Found", 404
    return send_from_directory(IMAGE_DIR, filename)

@app.route('/')
def index(): 
    return send_file('index.html')

if __name__ == '__main__':
    print(f"🚀 [已啟動] http://127.0.0.1:5000")
    app.run(debug=True, port=5000)